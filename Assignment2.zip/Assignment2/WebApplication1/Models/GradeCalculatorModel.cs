﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
//This model creates the getter and setter for the gradecalculator and requires a correct entry for each field in the form
namespace WebApplication1.Models
{
    public class GradeCalculatorModel
    {
        [Required]
        [Range(0, 100,
        ErrorMessage = "Grade for {0} must be between {1} and {2}.")]
        public int assignments { get; set; }
        [Required]
        [Range(0, 100,
        ErrorMessage = "Grade for {0} must be between {1} and {2}.")]
        public int project { get; set; }
        [Required]
        [Range(0, 100,
        ErrorMessage = "Grade for {0} must be between {1} and {2}.")]
        public int quizzes { get; set; }
        [Required]
        [Range(0, 100,
        ErrorMessage = "Grade for {0} must be between {1} and {2}.")]
        public int exam { get; set; }
        [Required]
        [Range(0, 100,
        ErrorMessage = "Grade for {0} must be between {1} and {2}.")]
        public int intex { get; set; }

    }
}
