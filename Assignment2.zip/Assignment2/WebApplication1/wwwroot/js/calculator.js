﻿//This is my javascript to calculate grades when the user clicks the Calculate Grade button. It does so by adding and weighing the grade inputs
$("#grades").click(function () {
    var finalGrade = ($("#assignments").val() * .5
        + $("#project").val() * .1
        + $("#quizzes").val() * .1
        + $("#exam").val() * .2
        + $("#intex").val() * .1);
    var letterGrade;
    switch (true) {
        case (finalGrade >= 94): letterGrade = "A";
            break;
        case (finalGrade >= 90): letterGrade = "A-";
            break;
        case (finalGrade >= 87): letterGrade = "B+";
            break;
        case (finalGrade >= 84): letterGrade = "B";
            break;
        case (finalGrade >= 80): letterGrade = "B-";
            break;
        case (finalGrade >= 77): letterGrade = "C+";
            break;
        case (finalGrade >= 74): letterGrade = "C";
            break;
        case (finalGrade >= 70): letterGrade = "C-";
            break;
        case (finalGrade >= 67): letterGrade = "D+";
            break;
        case (finalGrade >= 64): letterGrade = "D";
            break;
        case (finalGrade >= 60): letterGrade = "D-";
            break;
        case (finalGrade < 60): letterGrade = "E";
            break;
    }
    alert("Final Grade: " + finalGrade + "\n" + "Letter Grade: " + letterGrade);
});